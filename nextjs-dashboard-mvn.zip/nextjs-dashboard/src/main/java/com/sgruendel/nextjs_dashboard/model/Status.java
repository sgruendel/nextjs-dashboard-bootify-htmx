package com.sgruendel.nextjs_dashboard.model;


public enum Status {

    PENDING,
    PAID

}
